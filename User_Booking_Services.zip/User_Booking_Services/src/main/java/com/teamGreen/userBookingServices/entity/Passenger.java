package com.teamGreen.userBookingServices.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="passenger")
@Data
public class Passenger 
{
	String name;
	String age;
	Integer trainNumber;
	Integer pnr;
	Integer userId;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	Integer passengerId;
}
