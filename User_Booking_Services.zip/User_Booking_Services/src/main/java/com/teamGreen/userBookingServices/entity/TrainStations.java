package com.teamGreen.userBookingServices.entity;

import lombok.Data;

@Data
public class TrainStations {
	
	Integer trainNumber;
	String source;
	String destination;
	String intermediate1;
	String intermediate2;
	String intermediate3;
	String intermediate4;
	String intermediate5;
}
