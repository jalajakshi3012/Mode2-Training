package com.teamGreen.userBookingServices.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.teamGreen.userBookingServices.dao.BookingDAO;
import com.teamGreen.userBookingServices.dao.PassengerDAO;
import com.teamGreen.userBookingServices.dto.BookingDto;
import com.teamGreen.userBookingServices.dto.PassengerDetailsDto;
import com.teamGreen.userBookingServices.dto.PassengerDto;
import com.teamGreen.userBookingServices.entity.Booking;
import com.teamGreen.userBookingServices.entity.Passenger;
import com.teamGreen.userBookingServices.entity.Train;
import com.teamGreen.userBookingServices.exception.CancelNotAllowedException;
import com.teamGreen.userBookingServices.exception.InvalidPnrException;

@Service
public class PassengerService {

	@Autowired
	PassengerDAO passengerDAO;

	@Autowired
	BookingDAO bookingDAO;
	
	Generation generate;
	
	RestTemplate restTemplate = new RestTemplate();

	ModelMapper mapper = new ModelMapper();

	public BookingDto passengerDetails(List<PassengerDto> passengers, Integer pnr,Integer userId) {
		Booking booking = bookingDAO.getBookingDetails(pnr);
		if(booking==null) {
			throw new InvalidPnrException("Enter correct PNR number");
		}
		List<PassengerDetailsDto> list = new ArrayList<PassengerDetailsDto>();
		for (PassengerDto pass : passengers) {
			Passenger p = mapper.map(pass, Passenger.class);
			p.setTrainNumber(booking.getTrainNumber());
			p.setUserId(userId);
			p.setPnr(pnr);			
			passengerDAO.save(p);
			PassengerDetailsDto pdd = new PassengerDetailsDto();
			pdd.setPassengerId(p.getPassengerId());
			pdd.setPassengerName(p.getName());
			list.add(pdd);
		}
		BookingDto bookingDto = new BookingDto();
		bookingDto.setPassengerDetails(list);
		bookingDto = mapper.map(booking, BookingDto.class);
		return bookingDto;
	}

	public String cancelBookedTicket(Integer passengerId) {
		Optional<Passenger> passenger = passengerDAO.findById(passengerId);
		if(passenger.isPresent()) {
			
			Integer pnr = passenger.get().getPnr();
			Booking book = bookingDAO.findById(pnr).orElse(null);
			Integer trainNumber = book.getTrainNumber();
			System.out.println(trainNumber);
			LocalDate date = book.getDateOfJourney();
			String url2 = "http://localhost:8090/IRCTC/Admin/getTrainDetailsbyTrainNumber";
			String uri2 = UriComponentsBuilder.fromUriString(url2).queryParam("trainNumber", trainNumber).toUriString();
			
		    List<Train> trains = restTemplate.exchange(
		    		  uri2,
		    		  HttpMethod.GET,
		    		  null,
		    		  new ParameterizedTypeReference<List<Train>>() {}).getBody();

			int p1 = (book.getNoOfPassengers())-1;
			Iterator<Train> itr = trains.iterator();
			double fare=0;
			while(itr.hasNext()) {
				if(itr.next().getTrainPrimaryKey().getDate().equals(date)) {
					System.out.println("Inside");
					fare = (book.getTotalFare())-(itr.next().getFare());
					break;
				}
			}
			
			bookingDAO.updateBookingDetails(fare, p1, pnr);
			passengerDAO.deleteById(passengerId);
			
		}
		else {
			throw new CancelNotAllowedException("No Ticket to cancel");
		}
		
		
		return " Successfully Cancelled your Booked ticket";
		
	}
}
