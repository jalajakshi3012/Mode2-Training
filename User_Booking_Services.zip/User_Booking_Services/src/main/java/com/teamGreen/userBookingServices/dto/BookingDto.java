package com.teamGreen.userBookingServices.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.Data;
@Data
public class BookingDto {
	Integer pnr;
	Integer trainNumber;
	LocalDate dateOfJourney;
	String source;
	String destination;
	String startTime;
	String endTime;
	int noOfPassengers;
	double totalFare;
	
	List<PassengerDetailsDto> passengerDetails;
}
