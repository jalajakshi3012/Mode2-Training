package com.teamGreen.userBookingServices.service;

import java.net.URI;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.teamGreen.userBookingServices.dao.BookingDAO;
import com.teamGreen.userBookingServices.dto.TrainDto;
import com.teamGreen.userBookingServices.entity.Booking;
import com.teamGreen.userBookingServices.entity.Train;
import com.teamGreen.userBookingServices.entity.TrainStations;

@Service
public class BookingService {


	@Autowired
	BookingDAO bookingDAO;

	LocalDate doj;
	
	
	Generation generate = new Generation();

	RestTemplate restTemplate = new RestTemplate();
	Integer pnr = generate.generatePnr();

	public String bookingDetails(int numberOfPassengers, String date, Integer trainNumber) {

	
		doj = LocalDate.parse(date);

		String url = "http://localhost:8081/Admin/checkseatavailability";
		String uri = UriComponentsBuilder.fromUriString(url)
				.queryParam("date", date).queryParam("trainNumber", trainNumber).toUriString();

		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<?> entity = new HttpEntity<>(null, headers);
		int seatCount = restTemplate.exchange(uri, HttpMethod.GET, entity, Integer.class).getBody();
		//int seatCount = seatCount1;
		TrainDto train = new TrainDto();
		
		String url2 = "http://localhost:8090/IRCTC/Admin/userSearchByTrainNumber";
		String uri2 = UriComponentsBuilder.fromUriString(url2).queryParam("trainNumber", trainNumber).toUriString();
		
	    List<TrainDto> trains = restTemplate.exchange(
	    		  uri2,
	    		  HttpMethod.GET,
	    		  null,
	    		  new ParameterizedTypeReference<List<TrainDto>>() {}).getBody();
	   
		
		Iterator<TrainDto> itr = trains.iterator();
		while (itr.hasNext()) {
			if (itr.next().getDate().equals(doj)){
				System.out.println("I m in" + itr.next().toString());
				train = itr.next();
				break;
			}
		}

		Integer p1 = pnr++;

		String url1 = "http://localhost:8090/IRCTC/Admin/getStationByTrainNumber";
		URI uri1 = UriComponentsBuilder.fromUriString(url1).queryParam("trainNumber", trainNumber).build().toUri();

		ResponseEntity<List<TrainStations>> response1 = restTemplate.exchange(uri1, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<TrainStations>>() {
				});
		List<TrainStations> list = response1.getBody();
		boolean seatAvailability= (seatCount>=numberOfPassengers)?true:false;
		System.out.println("seat availability : "+seatAvailability);
		if (Boolean.TRUE.equals(seatAvailability)) {
			Booking booking = new Booking(p1, train.getTrainNumber(), train.getDate(), list.get(0).getSource(),
					list.get(0).getDestination(), train.getStartTime(), train.getEndTime(), numberOfPassengers,
					train.getFare() * numberOfPassengers);
			bookingDAO.save(booking);
			System.out.println("===========================");
			System.out.println("Booking saved");
			System.out.println("===========================");
			
			String str="Requested number of seats are available.please enter the passenger details. Available seats are: " + seatCount;
			return str;
		} else {
			return "seats not available. Available seats are: "+ seatCount;
		}

	}

	public int checkSeatAvailability(Integer trainNumber, String date) {
		doj = LocalDate.parse(date);
		Train train = new Train();
		
		String url = "http://localhost:8090/IRCTC/Admin/getTrainDetailsbyTrainNumber";
		URI uri = UriComponentsBuilder.fromUriString(url).queryParam("trainNumber", trainNumber).build().toUri();

		ResponseEntity<List<Train>> response = restTemplate.exchange(uri, HttpMethod.GET, null,
				new ParameterizedTypeReference<List<Train>>() {
				});

		List<Train> trains = response.getBody();
		Iterator<Train> itr = trains.iterator();
		while (itr.hasNext()) {
			if (itr.next().getTrainPrimaryKey().getDate().equals(doj)) {
				train = itr.next();
				System.out.println(train.toString());
				break;
			}
		}
		
		System.out.println(train.getSeatCount());
		return train.getSeatCount();
	}

}
