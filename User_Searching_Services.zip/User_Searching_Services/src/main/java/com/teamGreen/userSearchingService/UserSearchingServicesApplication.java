package com.teamGreen.userSearchingService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@SpringBootApplication
public class UserSearchingServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserSearchingServicesApplication.class, args);
	}

}
