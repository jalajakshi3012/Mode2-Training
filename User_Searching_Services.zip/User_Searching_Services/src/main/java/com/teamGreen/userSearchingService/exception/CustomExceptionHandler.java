package com.teamGreen.userSearchingService.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

@RestController
@ControllerAdvice
public class CustomExceptionHandler {
	@ExceptionHandler(TrainNumberNotFoundException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(TrainNumberNotFoundException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Entry Not Found", details);
		return new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(TrainDetailsNotFoundException.class)
	public final ResponseEntity<Object> handleEntryNotFoundException(TrainDetailsNotFoundException ex,
			WebRequest request) {
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ErrorResponse error = new ErrorResponse("Entry Not Found", details);
		return new ResponseEntity<Object>(error, HttpStatus.NOT_FOUND);
	}


}
