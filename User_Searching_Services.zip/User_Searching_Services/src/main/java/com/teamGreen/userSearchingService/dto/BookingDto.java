package com.teamGreen.userSearchingService.dto;

import java.time.LocalDate;

import lombok.Data;
@Data
public class BookingDto {
	Integer pnr;
	Integer trainNumber;
	LocalDate dateOfJourney;
	String source;
	String destination;
	String startTime;
	String endTime;
	int noOfPassengers;
	double totalFare;
}
