package com.teamGreen.userService.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.teamGreen.userService.Dao.RegistrationDAO;
import com.teamGreen.userService.Dto.RegistrationDto;
import com.teamGreen.userService.entity.Registration;

@Service
public class RegistrationService {
	
	@Autowired
	RegistrationDAO registrationDAO;
	
	ModelMapper mapper = new ModelMapper();

	public String registerUser(RegistrationDto registrationDto) {
		Registration registration = mapper.map(registrationDto, Registration.class);
		registrationDAO.save(registration);
		String str="Hi "+registrationDto.getUserName() + "!! You are Successfully Registered. "+"Your User Id id "+registration.getUserId();
		return str;
	}

	public String login(String username, String passwrd) {
		
		Registration login=registrationDAO.findByUserNameAndPasswrd(username, passwrd);
		if(login==null) {
		String str12 = "enter valid username and password";
		return str12;
		}
		else{
			String str3="You can now search for trains!!!!!" ;
			return str3;
		}

	}
}
