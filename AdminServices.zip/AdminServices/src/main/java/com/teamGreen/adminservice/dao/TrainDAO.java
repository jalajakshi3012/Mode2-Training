package com.teamGreen.adminservice.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.teamGreen.adminservice.entity.Train;
import com.teamGreen.adminservice.entity.TrainNumberAndDate;

public interface TrainDAO extends CrudRepository<Train, Integer>{

	public Train findByTrainPrimaryKey(TrainNumberAndDate compositeKeyTrain);
	
	String sql="select * from train where train_number=?1";
	@Query(value=sql,nativeQuery=true)
	List<Train> showListOfTrainDetails(Integer trainNumber);
	
	String sql4 = "select * from train where date=?1";	
	@Query(value=sql4, nativeQuery = true)
	List<Train> getByDate(LocalDate date);
	
}