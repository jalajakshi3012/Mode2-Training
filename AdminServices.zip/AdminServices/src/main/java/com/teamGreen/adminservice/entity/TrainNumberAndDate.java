package com.teamGreen.adminservice.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Embeddable;

import lombok.Data;


@Data
@Embeddable
public class TrainNumberAndDate implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	LocalDate date;
	Integer trainNumber;
}
