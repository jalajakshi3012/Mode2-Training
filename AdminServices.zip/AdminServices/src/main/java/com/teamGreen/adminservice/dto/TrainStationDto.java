package com.teamGreen.adminservice.dto;

import lombok.Data;

@Data
public class TrainStationDto {
	
	Integer trainNumber;
	String source;
	String destination;
	String intermediate1;
	String intermediate2;
	String intermediate3;
	String intermediate4;
	String intermediate5;
}
