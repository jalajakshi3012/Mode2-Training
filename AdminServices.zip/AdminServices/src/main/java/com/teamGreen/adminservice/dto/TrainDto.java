package com.teamGreen.adminservice.dto;

import java.io.Serializable;
import java.time.LocalDate;

import lombok.Data;

@Data
public class TrainDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Integer trainNumber;
	String source;
	String destination;
	String trainName;
	LocalDate date;
	String startTime;
	String endTime;
	double fare;
	
	public TrainDto() {
		super();
	}
	
	public TrainDto(Integer trainNumber, String source, String destination, String trainName, LocalDate date,
			String startTime, String endTime, double fare) {
		super();
		this.trainNumber = trainNumber;
		this.source = source;
		this.destination = destination;
		this.trainName = trainName;
		this.date = date;
		this.startTime = startTime;
		this.endTime = endTime;
		this.fare = fare;
	}

}