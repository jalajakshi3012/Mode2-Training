package com.teamGreen.adminservice.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.teamGreen.adminservice.dao.TrainDAO;
import com.teamGreen.adminservice.dao.TrainStationDAO;
import com.teamGreen.adminservice.dto.TrainDto;
import com.teamGreen.adminservice.entity.Train;
import com.teamGreen.adminservice.entity.TrainStations;

@Service
public class AdminServicesImpl implements AdminServices {

	@Autowired
	private TrainDAO trainDao;

	@Autowired
	private TrainStationDAO trainStationDao;

	@Override
	public boolean addTrains(List<Train> trains) {
		// TODO Auto-generated method stub
		boolean result = true;
		Iterator<Train> itr = trains.iterator();
		while (itr.hasNext()) {
			if (trainDao.findByTrainPrimaryKey(itr.next().getTrainPrimaryKey()) != null) {
				result = false;
				return result;
			}
		}
		trainDao.saveAll(trains);
		return result;

	}

	@Override
	public boolean addTrainStations(List<TrainStations> trainStations) {
		boolean result = true;
		//Iterator<TrainStations> itr = trainStations.iterator();
		/*
		 * while (itr.hasNext()) {
		 * 
		 * if (trainStationDao.findById(itr.next().getTrainNumber()) != null) { result =
		 * false; return result; } }
		 */

		trainStationDao.saveAll(trainStations);
		return result;
	}

	public List<TrainDto> trainSearchByFromToDate(String source, String destination, String date) {
		LocalDate date1 = LocalDate.parse(date);
		List<Train> list3 = trainDao.getByDate(date1);
		List<TrainStations> list4 = trainStationDao.getByStations(source, destination);
		System.out.println(list3.size());
		System.out.println(list4.size());
		System.out.println(list3.get(0).getTrainPrimaryKey().getTrainNumber());
		System.out.println(list4.get(0).getTrainNumber());
		List<TrainDto> finallist3 = new ArrayList<TrainDto>();
		for (int i = 0; i < list3.size(); i++) {
			System.out.println("inside for loop");
			
			for (int j = 0; j < list4.size(); j++) {
				System.out.println(list4.get(j).getTrainNumber()+" "+list4.size());
				if (list3.get(i).getTrainPrimaryKey().getTrainNumber().equals(list4.get(j).getTrainNumber())) {
					System.out.println("inside if");
					
					TrainDto trainDto = new TrainDto(list4.get(j).getTrainNumber(), list4.get(j).getSource(),
							list4.get(j).getDestination(), list3.get(i).getTrainName(),
							list3.get(i).getTrainPrimaryKey().getDate(), list3.get(i).getStartTime(),
							list3.get(i).getEndTime(), list3.get(i).getFare());
					finallist3.add(trainDto);
				}
			}
		}

		return finallist3;
	}

	public List<TrainDto> trainSearchByTrainNumber(Integer trainNumber) {
		List<Train> trains = trainDao.showListOfTrainDetails(trainNumber);
		List<TrainStations> list2 = trainStationDao.getTrainStations(trainNumber);

		List<TrainDto> finallist = new ArrayList<TrainDto>();
		for (int i = 0; i < trains.size(); i++) {
			if (trains.get(i).getTrainPrimaryKey().getTrainNumber().equals(list2.get(0).getTrainNumber())) {

				TrainDto trainDto = new TrainDto(list2.get(0).getTrainNumber(), list2.get(0).getSource(),
						list2.get(0).getDestination(), trains.get(i).getTrainName(),
						trains.get(i).getTrainPrimaryKey().getDate(), trains.get(i).getStartTime(),
						trains.get(i).getEndTime(), trains.get(i).getFare());
				finallist.add(trainDto);
			}

		}
		return finallist;
	}

	@Override
	public List<Train> getTrainByTrainNumber(Integer trainNumber) {
		return trainDao.showListOfTrainDetails(trainNumber);
	}

	@Override
	public List<TrainStations> getTrainStationByNumber(Integer trainNumber) {
		// TODO Auto-generated method stub
		return trainStationDao.getTrainStations(trainNumber);
	}

}
